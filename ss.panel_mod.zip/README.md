# 介绍

一个修改的 ss panel 版本，多了蛮多新东西。

# 准备

1.一台 VPS

# 环境

1.PHP 5.6 + (推荐 PHP 7.1.1)
2.MYSQL 5.5 + 
3.以及安装和配置过程中涉及到的种种东西。

# 安装

[https://github.com/esdeathlove/ss-panel-v3-mod/wiki/%E5%AE%89%E8%A3%85%E8%AF%B4%E6%98%8E](https://github.com/esdeathlove/ss-panel-v3-mod/wiki/%E5%AE%89%E8%A3%85%E8%AF%B4%E6%98%8E)

# FAQ

[https://github.com/esdeathlove/ss-panel-v3-mod/wiki/FAQ](https://github.com/esdeathlove/ss-panel-v3-mod/wiki/FAQ)

# 遇到问题？

不好意思，使用上的，比如说你不会使用，请自行看现在已有的[说明](https://github.com/esdeathlove/ss-panel-v3-mod/wiki/)以及自行琢磨。

如果你发现了你认为你实在无法解决的问题，请在 [https://github.com/esdeathlove/ss-panel-v3-mod/issues](https://github.com/esdeathlove/ss-panel-v3-mod/issues) 按照所提示的 issue 模板，进行反馈以及获得解决方案。发送 issue 之前请三思，不恰当的内容可能会造成你之后都无法获得回应。

# 最新消息获取

[Telegram频道 glzjinmodnews](https://t.me/glzjinmodnews)


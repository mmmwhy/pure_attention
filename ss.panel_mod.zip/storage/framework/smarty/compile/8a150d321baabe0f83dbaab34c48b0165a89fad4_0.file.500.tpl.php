<?php
/* Smarty version 3.1.31, created on 2017-05-27 13:01:23
  from "/home/wwwroot/ss.panel/resources/views/material/500.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59290823860ee6_79189177',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8a150d321baabe0f83dbaab34c48b0165a89fad4' => 
    array (
      0 => '/home/wwwroot/ss.panel/resources/views/material/500.tpl',
      1 => 1495860748,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_59290823860ee6_79189177 (Smarty_Internal_Template $_smarty_tpl) {
?>





<?php $_smarty_tpl->_subTemplateRender('file:header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-lg-push-0 col-sm-12 col-sm-push-0">
						<h1 class="content-heading">500</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
						<section class="content-inner margin-top-no">
							
							
							<div class="card">
								<div class="card-main">
									<div class="card-inner">
										<p>您试图访问的页面地址出错了。如果您认为这个错误不该发生，<a href="https://github.com/glzjin/ss-panel-v3-mod/issues">请到 Github 提交 issue</a>。</p>
									</div>
									
									<div class="card-action">
										<div class="card-action-btn pull-left">
											<a class="btn btn-flat waves-attach" href="javascript:history.back()"><span class="icon">backspace</span>&nbsp;返回</a>
										</div>
									</div>
									
								</div>
							</div>

								
							<div class="card">
								<div class="card-main">
									<div class="card-inner">
											<div class="card-img">
												<img src="<?php echo $_smarty_tpl->tpl_vars['pic']->value;?>
" style="width: 100%;">
											</div>
									</div>
									
									
								</div>
							</div>
							

		
							
						</section>
			
			
			
		</div>
	</main>


<?php $_smarty_tpl->_subTemplateRender('file:footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}

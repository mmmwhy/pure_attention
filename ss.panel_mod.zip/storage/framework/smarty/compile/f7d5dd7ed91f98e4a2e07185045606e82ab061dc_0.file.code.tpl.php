<?php
/* Smarty version 3.1.31, created on 2017-05-27 13:03:47
  from "/home/wwwroot/ss.panel/resources/views/material/user/code.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_592908b3337788_55916129',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f7d5dd7ed91f98e4a2e07185045606e82ab061dc' => 
    array (
      0 => '/home/wwwroot/ss.panel/resources/views/material/user/code.tpl',
      1 => 1495860748,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_592908b3337788_55916129 (Smarty_Internal_Template $_smarty_tpl) {
?>









<?php $_smarty_tpl->_subTemplateRender('file:user/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>








	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<h1 class="content-heading">请选择一种方式进行充值</h1>
			</div>
		</div>
		<div class="container">
			<section class="content-inner margin-top-no">
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="card margin-bottom-no">
							<div class="card-main">
								<div class="card-inner">
									<div class="card-inner">
										<p class="card-heading">使用充值码</p>
										<p>（请联系管理员或发【工单】索要充值码，并注明所需金额）
										<p>当前余额：<?php echo $_smarty_tpl->tpl_vars['user']->value->money;?>
 元</p>
										<div class="form-group form-group-label">
											<label class="floating-label" for="code">充值码</label>
											<input class="form-control" id="code" type="text">
										</div>
									</div>
									<div class="card-action">
										<div class="card-action-btn pull-left">
											<button class="btn btn-flat waves-attach" id="code-update" ><span class="icon">check</span>&nbsp;充值</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<?php if ($_smarty_tpl->tpl_vars['pmw']->value != '') {?>
					<div class="col-lg-12 col-md-12">
						<div class="card margin-bottom-no">
							<div class="card-main">
								<div class="card-inner">
									<div class="card-inner">
										<?php echo $_smarty_tpl->tpl_vars['pmw']->value;?>

									</div>
									
								</div>
							</div>
						</div>
					</div>
					<?php }?>
					
					<div class="col-lg-12 col-md-12">
						<div class="card margin-bottom-no">
							<div class="card-main">
								<div class="card-inner">
									<div class="card-inner">
										<div class="card-table">
											<div class="table-responsive">
												<?php echo $_smarty_tpl->tpl_vars['codes']->value->render();?>

												<p class="card-heading">充值记录</p>
												<table class="table table-hover">
													<tr>
														<th>ID</th>
														<th>代码</th>
														<th>类型</th>
														<th>操作</th>
														<th>使用时间</th>
														
													</tr>
													<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['codes']->value, 'code');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['code']->value) {
?>
														<?php if ($_smarty_tpl->tpl_vars['code']->value->type != -2) {?>
															<tr>
																<td>#<?php echo $_smarty_tpl->tpl_vars['code']->value->id;?>
</td>
																<td><?php echo $_smarty_tpl->tpl_vars['code']->value->code;?>
</td>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == -1) {?>
																<td>金额充值</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == 10001) {?>
																<td>流量充值</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == 10002) {?>
																<td>用户续期</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type >= 1 && $_smarty_tpl->tpl_vars['code']->value->type <= 10000) {?>
																<td>等级续期 - 等级<?php echo $_smarty_tpl->tpl_vars['code']->value->type;?>
</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == -1) {?>
																<td>充值 <?php echo $_smarty_tpl->tpl_vars['code']->value->number;?>
 元</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == 10001) {?>
																<td>充值 <?php echo $_smarty_tpl->tpl_vars['code']->value->number;?>
 GB 流量</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type == 10002) {?>
																<td>延长账户有效期 <?php echo $_smarty_tpl->tpl_vars['code']->value->number;?>
 天</td>
																<?php }?>
																<?php if ($_smarty_tpl->tpl_vars['code']->value->type >= 1 && $_smarty_tpl->tpl_vars['code']->value->type <= 10000) {?>
																<td>延长等级有效期 <?php echo $_smarty_tpl->tpl_vars['code']->value->number;?>
 天</td>
																<?php }?>
																<td><?php echo $_smarty_tpl->tpl_vars['code']->value->usedatetime;?>
</td>
															</tr>
														<?php }?>
													<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

												</table>
												<?php echo $_smarty_tpl->tpl_vars['codes']->value->render();?>

											</div>
										</div>
									</div>
									
								</div>
							</div>
						</div>
					</div>
					
					<div aria-hidden="true" class="modal modal-va-middle fade" id="readytopay" role="dialog" tabindex="-1">
						<div class="modal-dialog modal-xs">
							<div class="modal-content">
								<div class="modal-heading">
									<a class="modal-close" data-dismiss="modal">×</a>
									<h2 class="modal-title">正在连接支付宝</h2>
								</div>
								<div class="modal-inner">
									<p id="title">正在处理...</p>
								</div>
							</div>
						</div>
					</div>
					
					<div aria-hidden="true" class="modal modal-va-middle fade" id="alipay" role="dialog" tabindex="-1">
						<div class="modal-dialog modal-xs">
							<div class="modal-content">
								<div class="modal-heading">
									<a class="modal-close" data-dismiss="modal">×</a>
									<h2 class="modal-title">请使用支付宝App扫码充值：</h2>
								</div>
								<div class="modal-inner">
									<p id="title">订单二维码</p>
									<p id="divide">-------------------------------------------------------------</p>
									<p id="qrcode"></p>
									<p id="info"></p>
								</div>
								
								<div class="modal-footer">
									<p class="text-right"><button class="btn btn-flat btn-brand waves-attach" data-dismiss="modal" id="alipay_cancel" type="button">取消</button></p>
								</div>
							</div>
						</div>
					</div>
					
					<?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

				</div>
			</section>
		</div>
	</main>







<?php $_smarty_tpl->_subTemplateRender('file:user/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



<?php echo '<script'; ?>
>
	$(document).ready(function () {
		$("#code-update").click(function () {
			$.ajax({
				type: "POST",
				url: "code",
				dataType: "json",
				data: {
					code: $("#code").val()
				},
				success: function (data) {
					if (data.ret) {
						$("#result").modal();
						$("#msg").html(data.msg);
						window.setTimeout("location.href=window.location.href", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
					} else {
						$("#result").modal();
						$("#msg").html(data.msg);
						window.setTimeout("location.href=window.location.href", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
					}
				},
				error: function (jqXHR) {
					$("#result").modal();
					$("#msg").html("发生错误：" + jqXHR.status);
				}
			})
		})
		
		$("#urlChange").click(function () {
			$.ajax({
				type: "GET",
				url: "code/f2fpay",
				dataType: "json",
				data: {
					time: timestamp
				},
				success: function (data) {
					if (data.ret) {
						$("#readytopay").modal();
					}
				}
				
			})
		});
		
		$("#readytopay").on('shown.bs.modal', function () {
			$.ajax({
				type: "POST",
				url: "code/f2fpay",
				dataType: "json",
				data: {
						amount: $("#type").find("option:selected").val()
					},
				success: function (data) {
					$("#readytopay").modal('hide');
					if (data.ret) {
						$("#qrcode").html(data.qrcode);
						$("#info").html("您的订单金额为："+data.amount+"元。");
						$("#alipay").modal();
					} else {
						$("#result").modal();
						$("#msg").html(data.msg);
					}
				},
				error: function (jqXHR) {
					$("#readytopay").modal('hide');
					$("#result").modal();
					$("#msg").html(data.msg+"  发生了错误。");
				}
			})
		});

		
	timestamp = <?php echo time();?>
; 
		
		
	function f(){
		$.ajax({
			type: "GET",
			url: "code_check",
			dataType: "json",
			data: {
				time: timestamp
			},
			success: function (data) {
				if (data.ret) {
					clearTimeout(tid);
					$("#alipay").modal('hide');
					$("#result").modal();
					$("#msg").html("充值成功！");
					window.setTimeout("location.href=window.location.href", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
				}
			}
		});
		tid = setTimeout(f, 1000); //循环调用触发setTimeout
	}
	setTimeout(f, 1000);
})
<?php echo '</script'; ?>
>

<?php }
}

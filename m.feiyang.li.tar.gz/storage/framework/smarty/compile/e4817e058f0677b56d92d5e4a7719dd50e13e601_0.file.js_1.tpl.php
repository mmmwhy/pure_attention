<?php
/* Smarty version 3.1.31, created on 2017-06-10 12:58:14
  from "/www/wwwroot/m.feiyang.li/resources/views/material/table/js_1.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_593b7c661a5b56_31014073',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e4817e058f0677b56d92d5e4a7719dd50e13e601' => 
    array (
      0 => '/www/wwwroot/m.feiyang.li/resources/views/material/table/js_1.tpl',
      1 => 1496990163,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593b7c661a5b56_31014073 (Smarty_Internal_Template $_smarty_tpl) {
?>
function modify_table_visible(id, key) {
	if(document.getElementById(id).checked)
	{
		table_1.columns( '.' + key ).visible( true );
		localStorage.setItem(window.location.href + '-haschecked-' + id, true);
	}
	else
	{
		table_1.columns( '.' + key ).visible( false );
		localStorage.setItem(window.location.href + '-haschecked-' + id, false);
	}
}
<?php }
}

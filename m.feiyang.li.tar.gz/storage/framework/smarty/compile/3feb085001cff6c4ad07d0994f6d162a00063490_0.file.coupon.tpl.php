<?php
/* Smarty version 3.1.31, created on 2017-06-11 09:19:34
  from "/www/wwwroot/m.feiyang.li/resources/views/material/admin/coupon.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_593c9aa68f3da0_92522816',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3feb085001cff6c4ad07d0994f6d162a00063490' => 
    array (
      0 => '/www/wwwroot/m.feiyang.li/resources/views/material/admin/coupon.tpl',
      1 => 1496990164,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/main.tpl' => 1,
    'file:table/checkbox.tpl' => 1,
    'file:table/table.tpl' => 1,
    'file:dialog.tpl' => 1,
    'file:admin/footer.tpl' => 1,
    'file:table/js_1.tpl' => 1,
    'file:table/js_2.tpl' => 1,
  ),
),false)) {
function content_593c9aa68f3da0_92522816 (Smarty_Internal_Template $_smarty_tpl) {
?>






<?php $_smarty_tpl->_subTemplateRender('file:admin/main.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>








	<main class="content">
		<div class="content-header ui-content-header">
			<div class="container">
				<h1 class="content-heading">优惠码</h1>
			</div>
		</div>
		<div class="container">
				<section class="content-inner margin-top-no">



					<div class="card">
						<div class="card-main">
							<div class="card-inner">
								<div class="form-group form-group-label">
									<label class="floating-label" for="prefix">优惠码前缀</label>
									<input class="form-control" id="prefix" type="text">
								</div>

								<div class="form-group form-group-label">
									<label class="floating-label" for="credit">优惠码额度(百分比，九折就填 10 )</label>
									<input class="form-control" id="credit" type="text">
								</div>

								<div class="form-group form-group-label">
									<label class="floating-label" for="expire">优惠码有效期(h)</label>
									<input class="form-control" id="expire" type="number" value="1">
								</div>

								<div class="form-group form-group-label">
									<label class="floating-label" for="shop">优惠码可用商品ID，不填即为所有商品可用，多个的话用英文半角逗号分割</label>
									<input class="form-control" id="shop" type="text">
								</div>

								<div class="form-group form-group-label">
									<div class="checkbox switch">
										<label for="onetime">
											<input class="access-hide" id="onetime" type="checkbox"><span class="switch-toggle"></span>一次性的,只在用户当次购买时有效
										</label>
									</div>
								</div>


								<div class="form-group">
									<div class="row">
										<div class="col-md-10 col-md-push-1">
											<button id="coupon" type="submit" class="btn btn-block btn-brand waves-attach waves-light">生成</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="card margin-bottom-no">
						<div class="card-main">
							<div class="card-inner">
								<p class="card-heading">优惠码</p>
								<p>显示表项:
									<?php $_smarty_tpl->_subTemplateRender('file:table/checkbox.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

								</p>
								<div class="card-table">
									<div class="table-responsive">
										<?php $_smarty_tpl->_subTemplateRender('file:table/table.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

									</div>
								</div>
							</div>
						</div>
					</div>

					<?php $_smarty_tpl->_subTemplateRender('file:dialog.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>



			</div>



	</main>












<?php $_smarty_tpl->_subTemplateRender('file:admin/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>






<?php echo '<script'; ?>
>

<?php $_smarty_tpl->_subTemplateRender('file:table/js_1.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


$(document).ready(function () {
		<?php $_smarty_tpl->_subTemplateRender('file:table/js_2.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


		$("#coupon").click(function () {

				if(document.getElementById('onetime').checked)
				{
						var onetime=1;
				}
				else
				{
						var onetime=0;
				}

	      $.ajax({
		          type: "POST",
		          url: "/admin/coupon",
		          dataType: "json",
		          data: {
		          prefix: $("#prefix").val(),
		          credit: $("#credit").val(),
							shop: $("#shop").val(),
							onetime: onetime,
		          expire: $("#expire").val()
		          },
		          success: function (data) {
		              if (data.ret) {
		                  $("#result").modal();
		                  $("#msg").html(data.msg);
		                  window.setTimeout("location.href='/admin/coupon'", <?php echo $_smarty_tpl->tpl_vars['config']->value['jump_delay'];?>
);
		              }
		              // window.location.reload();
		          },
		          error: function (jqXHR) {
		              alert("发生错误：" + jqXHR.status);
		          }
	      })
		})
})
<?php echo '</script'; ?>
>
<?php }
}

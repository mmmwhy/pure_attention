<?php
/* Smarty version 3.1.31, created on 2017-06-10 12:50:58
  from "/www/wwwroot/m.feiyang.li/resources/views/material/reg_tos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_593b7ab2b7c618_72742001',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '67d196c5c1a677aad0200d1075d9943155eab7cc' => 
    array (
      0 => '/www/wwwroot/m.feiyang.li/resources/views/material/reg_tos.tpl',
      1 => 1496990163,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_593b7ab2b7c618_72742001 (Smarty_Internal_Template $_smarty_tpl) {
?>
<ul>
	<li>用户注册时候需要提供邮箱以及密码，并自行保管。邮箱为用户的唯一凭证。</li>
	<li>本站会加密存储用户密码，尽量保证数据安全，但并不保证这些信息的绝对安全。</li>
	<li>禁止使用本站服务进行任何违法恶意活动。</li>
	<li>使用任何节点，需遵循节点所属国家的相关法律以及中国法律。</li>
	<li>禁止滥用本站提供的服务。</li>
	<li>对于免费用户，我们有权在不通知的情况下删除账户。</li>
	<li>任何违法使用条款的用户，我们将会删除违规账户并没收使用本站服务的权利。</li>
</ul><?php }
}

<?  
phpinfo();  
?>  